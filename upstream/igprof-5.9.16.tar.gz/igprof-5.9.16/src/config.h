#ifndef CONFIG_H
#define CONFIG_H

#define PCRE_FOUND
/* #undef USER_CCNT */

#endif // CONFIG_H
